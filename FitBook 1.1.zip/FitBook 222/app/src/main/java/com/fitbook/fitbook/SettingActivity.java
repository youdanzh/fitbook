package com.fitbook.fitbook;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import java.util.List;

public class  SettingActivity extends BaseActivity {
    private Paypal paypal;
    private EditText etName;
    private EditText etCard;
    private EditText etTime;
    private EditText etCvv;
    private EditText etAddress;
    private EditText etPwd;
    private int userId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addcard);
        onSetTitle("Setting");
        initView();
        userId = (int) SPUtils.get(this, "id", 0);
        List<Paypal> paypalList = DBDao.getInstance(this).loadPaypalByUser(userId);
        if (paypalList!=null&&paypalList.size()>0){
            paypal = paypalList.get(0);
            etName.setText(paypal.getName());
            etCard.setText(paypal.getCardNo());
            etTime.setText(paypal.getTime());
            etCvv.setText(paypal.getCvv());
            etAddress.setText(paypal.getAddress());
            etPwd.setText(paypal.getPwd());
        }
    }

    private void initView() {
        etName = findViewById(R.id.edt_name);
        etCard = findViewById(R.id.et_card);
        etTime = findViewById(R.id.edt_time);
        etCvv = findViewById(R.id.et_cvv);
        etAddress = findViewById(R.id.et_address);
        etPwd = findViewById(R.id.edt_pay_pwd);
        View btSubmit = findViewById(R.id.bt_submit);
        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etName.getText().toString();
                String carNo = etName.getText().toString();
                String time = etTime.getText().toString();
                String cvv = etCvv.getText().toString();
                String address = etAddress.getText().toString();
                String pwd = etPwd.getText().toString();
                if (TextUtils.isEmpty(name)){
                    onToast("Name cannot be blank");
                    return;
                }
                if (TextUtils.isEmpty(carNo)){
                    onToast("Card number cannot be blank");
                    return;
                }
                if (TextUtils.isEmpty(time)){
                    onToast("Expire Date cannot be blank");
                    return;
                }
                if (TextUtils.isEmpty(cvv)){
                    onToast("cvv cannot be blank");
                    return;
                }
                if (TextUtils.isEmpty(address)){
                    onToast("address cannot be blank");
                    return;
                }
                if (TextUtils.isEmpty(pwd)){
                    onToast("Password cannot be blank");
                    return;
                }
                if (paypal!=null){
                    paypal.setName(name);
                    paypal.setCardNo(carNo);
                    paypal.setTime(time);
                    paypal.setCvv(cvv);
                    paypal.setAddress(address);
                    paypal.setPwd(pwd);
                    DBDao.getInstance(SettingActivity.this).updatePaypal(paypal);
                    onToast("Successful");
                }else{
                    Paypal paypal = new Paypal(name, carNo, time,cvv,address,pwd,userId+"");
                    DBDao.getInstance(SettingActivity.this).insertPaypal(paypal);
                    onToast("Add successful");
                }
            }
        });
    }
}
