package com.fitbook.fitbook;

import android.content.ContentValues;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//Clock in / out class
public class Work {
    private int status ;//0= working 1 = not working
    private int userId;//UderID
    private String time;//clockin time
    private int hours;//total hours

    public Work(int status, int userId, String time,int hours) {
        this.status = status;
        this.userId = userId;
        this.time = time;
        this.hours = hours;
    }
    public static ContentValues getValues(Work work){
        ContentValues cv = new ContentValues();
        cv.put("status", work.getStatus());
        cv.put("userId", work.getUserId());
        cv.put("time", work.getTime());
        cv.put("hours", work.getHours());
        return cv;
    }

    public int getHours() { return hours; }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static int hour(String startTime, String endTime){
        int hours = 0;
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            long from = simpleFormat.parse(startTime).getTime();
            long to = simpleFormat.parse(endTime).getTime();
            hours = (int) ((to - from)/(1000 * 60 * 60));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return hours;
    }
    public static String getNowTime(){ //data format for time
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm");
       return df.format(new Date());
    }
}
