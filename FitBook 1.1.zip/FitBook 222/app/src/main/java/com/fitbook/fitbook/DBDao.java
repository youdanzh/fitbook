package com.fitbook.fitbook;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;


public class DBDao {

    private static DBDao userDB;

    private SQLiteDatabase db;

    private DBDao(Context context) {
        DBHelper dbHelper = new DBHelper(context, "wz.db", null, 1);
        db = dbHelper.getWritableDatabase();
    }
    public static DBDao getInstance(Context context) {
        if (userDB == null) {
            userDB = new DBDao(context);
        }
        return userDB;
    }

    public void updateUser(User user){
        if (user != null) {
          db.update("user",User.getUserValues(user),"uid"+ "= ? ", new String[]{user.getUid()+""}) ;
        }
    }

    public Boolean delUser(String id) {
        db.delete("user", "uid" + "=?" , new String[]{id});
        return  false;
    }
    public boolean  registerUser(User user) {
        if (user != null) {
            Cursor cursor = db .query("user", null, "uname=?", new String[]{user.getUname()}, null, null, null);
            if (cursor.getCount() > 0) {
                return false;
            } else {
                db.insert("user",null,User.getUserValues(user));
                return true;
            }
        }
        return false;

    }
    public List<User> loadEmployee(){
        ArrayList<User> noteList = new ArrayList<>();
        Cursor cursor = db.query("user", null, "userType=?", new String[]{"1"}, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int uid  = cursor.getInt(cursor.getColumnIndex("uid"));
                String uname  = cursor.getString(cursor.getColumnIndex("uname"));
                String upasswd  = cursor.getString(cursor.getColumnIndex("upasswd"));
                String utel  = cursor.getString(cursor.getColumnIndex("utel"));
                String utext  = cursor.getString(cursor.getColumnIndex("utext"));
                String usex  = cursor.getString(cursor.getColumnIndex("usex"));
                String vipType  = cursor.getString(cursor.getColumnIndex("vipType"));
                String vipDays  = cursor.getString(cursor.getColumnIndex("vipDays"));
                String salary  = cursor.getString(cursor.getColumnIndex("salary"));
                int userType  = cursor.getInt(cursor.getColumnIndex("userType"));
                User user= new User(uid,uname,upasswd,utel,utext,usex,vipType,vipDays,userType,salary);
                noteList.add(user);
            }

            cursor.close();
        }
        return noteList;
    }
    public User getUserInfoById(int id) {
        User user = null;
        Cursor cursor = db .query("user", null, "uid"+"="+id, null, null, null, null);
        if(cursor!=null){
            if(cursor.getCount()>0){
                cursor.moveToFirst();
                int uid  = cursor.getInt(cursor.getColumnIndex("uid"));
                String uname  = cursor.getString(cursor.getColumnIndex("uname"));
                String upasswd  = cursor.getString(cursor.getColumnIndex("upasswd"));
                String utel  = cursor.getString(cursor.getColumnIndex("utel"));
                String utext  = cursor.getString(cursor.getColumnIndex("utext"));
                String usex  = cursor.getString(cursor.getColumnIndex("usex"));
                String vipType  = cursor.getString(cursor.getColumnIndex("vipType"));
                String vipDays  = cursor.getString(cursor.getColumnIndex("vipDays"));
                String salary  = cursor.getString(cursor.getColumnIndex("salary"));
                int userType  = cursor.getInt(cursor.getColumnIndex("userType"));
                user = new User(uid,uname,upasswd,utel,utext,usex,vipType,vipDays,userType,salary);

            }
            cursor.close();
        }
        return user;
    }

    public int userLogin(String name , String password){
        Cursor cursor = db .query("user", null, "uname=?"+" and "+"upasswd=?", new String[]{name,password}, null, null, null);
        if (cursor.getCount()>0){
            cursor.moveToNext();
            return cursor.getInt(cursor.getColumnIndex("uid"));
        }else {
            return -1;
        }


    }
    public List<Paypal> loadPaypalByUser(int uid){
        ArrayList<Paypal> noteList = new ArrayList<>();
        Cursor cursor = db.query("paypal", null, "uid=?", new String[]{uid+""}, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String cardNo = cursor.getString(cursor.getColumnIndex("cardNo"));
                String time = cursor.getString(cursor.getColumnIndex("time"));
                String cvv = cursor.getString(cursor.getColumnIndex("cvv"));
                String address = cursor.getString(cursor.getColumnIndex("address"));
                String pwd = cursor.getString(cursor.getColumnIndex("pwd"));
                String userId = cursor.getString(cursor.getColumnIndex("uid"));
                Paypal note = new Paypal(id,name, cardNo, time,cvv,address,pwd,userId);
                noteList.add(note);
            }

            cursor.close();
        }
        return noteList;
    }


    public Boolean insertPaypal(Paypal note) {
        if (note != null) {
            long result = db.insert("paypal", null, Paypal.getValues(note));
            return result != -1;
        }
        return  false;
    }

    public Boolean updatePaypal(Paypal order) {
        if (order != null) {
            long result = db.update("paypal", Paypal.getValues(order),"id" + "=?" , new String[]{order.getId()+""});
            return result != -1;
        }
        return  false;
    }

    public Work getWorkInfo(int id) {
        Work user = null;
        Cursor cursor = db .query("work", null, "userId"+"="+id, null, null, null, null);
        if(cursor!=null){
            if(cursor.getCount()>0){
                cursor.moveToFirst();
                int uid  = cursor.getInt(cursor.getColumnIndex("userId"));
                String time  = cursor.getString(cursor.getColumnIndex("time"));
                int status  = cursor.getInt(cursor.getColumnIndex("status"));
                int hours  = cursor.getInt(cursor.getColumnIndex("hours"));
                user = new Work(status,uid,time,hours);

            }
            cursor.close();
        }
        return user;
    }
    public void updateWork(Work work){
        if (work != null) {
            db.update("work",Work.getValues(work),"userId"+ "= ? ", new String[]{work.getUserId()+""}) ;
        }
    }
    public void addWork(Work work){
        if (work != null) {
            db.insert("work", null, Work.getValues(work));
        }
    }
    public void addRecord(EmployeeRecord record){
        if (record != null) {
            db.insert("record", null, EmployeeRecord.getValues(record));
        }
    }
    public List<EmployeeRecord> loadRecordByUser(int uid){
        ArrayList<EmployeeRecord> noteList = new ArrayList<>();
        Cursor cursor = db.query("record", null, "userId=?", new String[]{uid+""}, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int userId = cursor.getInt(cursor.getColumnIndex("userId"));
                String startTime = cursor.getString(cursor.getColumnIndex("startTime"));
                String endTime = cursor.getString(cursor.getColumnIndex("endTime"));
                String salary = cursor.getString(cursor.getColumnIndex("salary"));
                String total = cursor.getString(cursor.getColumnIndex("total"));
                EmployeeRecord note = new EmployeeRecord(startTime,endTime, salary, total,userId);
                noteList.add(note);
            }
            cursor.close();
        }
        return noteList;
    }
}
