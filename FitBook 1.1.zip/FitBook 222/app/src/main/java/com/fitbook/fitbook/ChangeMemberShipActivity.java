package com.fitbook.fitbook;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class ChangeMemberShipActivity extends BaseActivity {
    private RadioGroup rgType;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.changemembership);
        onSetTitle("Change Membership");
        initView();
    }

    private void initView() {
        rgType = findViewById(R.id.rg_type);
        Button btPay = findViewById(R.id.bt_pay);
        btPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int checkId = rgType.getCheckedRadioButtonId();

                //Member can change gym plan option
                if (checkId==R.id.rb_one){
                    change("3 year","1095 days");


                }else  if (checkId==R.id.rb_two){
                    change("1 year","365 days");
                }else  if (checkId==R.id.rb_three){
                    change("3 month","90 days");
                }else  if (checkId==R.id.rb_four){
                    change("1 month","30 days");
                }
            }
        });

    }

    private void change(String s, String s1) {
        int id = (int) SPUtils.get(ChangeMemberShipActivity.this, "id", 0);
        final User user = DBDao.getInstance(ChangeMemberShipActivity.this).getUserInfoById(id);
        user.setVipType(s);
        user.setVipDays(s1);
        new AlertDialog.Builder(ChangeMemberShipActivity.this)
                .setTitle("Notice")
                .setMessage("Are you sure to change the membership type")
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        DBDao.getInstance(ChangeMemberShipActivity.this).updateUser(user);
                        onToast("Successful");
                        finish();
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).create().show();

    }
}
