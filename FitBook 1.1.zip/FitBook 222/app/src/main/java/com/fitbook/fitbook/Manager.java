package com.fitbook.fitbook;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;

public class Manager  extends BaseActivity{

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.managerview);
        onSetTitle("Manager");
        Button btList = findViewById(R.id.bt_list);
        Button btAddEmployee = findViewById(R.id.add_employee);
        btList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Manager.this,EmployeeListActivity.class));
            }
        });
        btAddEmployee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Manager.this,AddEmployeeActivity.class));
            }
        });
    }
}
