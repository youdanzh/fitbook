package com.fitbook.fitbook;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;
//Employee list class
public class EmployeeAdapter extends RecyclerView.Adapter<EmployeeAdapter.DataHolder>{
    private List<User> userList;
    private Context context;

    public EmployeeAdapter(Context context, List<User> data) {
        userList = data;
        this.context = context;
    }

    @Override
    public DataHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.item_employee,parent,false);
        return new DataHolder(view);
    }

    @Override
    public void onBindViewHolder(DataHolder holder, final int position) {
        User user = userList.get(position);
        holder.saveData(user);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener!=null){
                    listener.setOnItemClickListener(position);
                }
            }
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (longlistener!=null){
                    longlistener.setOnItemClickListener(position);
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }
    private ItemClickListener listener;
    public void setOnItemClickListener(ItemClickListener listener ){
        this.listener = listener;
    }
    public interface ItemClickListener{
        void setOnItemClickListener(int position);
    }
    private ItemLongClickListener longlistener;
    public void setOnItemLongClickListener(ItemLongClickListener listener ){
        this.longlistener = listener;
    }
    public interface ItemLongClickListener{
        void setOnItemClickListener(int position);
    }
    public class DataHolder extends RecyclerView.ViewHolder {
        private TextView tv_gz,tv_name,tv_no,tv_hour;

        public DataHolder(View itemView) {
            super(itemView);
            tv_no= itemView.findViewById(R.id.tv_no);
            tv_name= itemView.findViewById(R.id.tv_name);
            tv_gz= itemView.findViewById(R.id.tv_gz);
            tv_hour= itemView.findViewById(R.id.tv_hour);
        }
        //save employee data will store in database
        public void saveData(User x){
            tv_no.setText(x.getUid()+""); //get employee id
            tv_name.setText(x.getUname()+""); //get employee name
            tv_gz.setText(x.getSalary()+"$/h"); //get employee salary
            Work work = DBDao.getInstance(context).getWorkInfo(x.getUid());
            if(work!=null) {
                tv_hour.setText(work.getHours() + ""); //hours worked
            }
        }

    }
}
