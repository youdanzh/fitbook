
package com.fitbook.fitbook;


import android.content.ContentValues;

class EmployeeRecord {
    private String startTime;
    private String endTime;
    private String salary;
    private String total;
    private int userId;

    public EmployeeRecord(String startTime, String endTime, String salary, String total, int userId) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.salary = salary;
        this.total = total;
        this.userId = userId;
    }

    public static ContentValues getValues(EmployeeRecord record){
        ContentValues cv = new ContentValues();
        cv.put("startTime", record.getStartTime());
        cv.put("endTime", record.getEndTime());
        cv.put("salary", record.getSalary());
        cv.put("total", record.getTotal());
        cv.put("userId", record.getUserId());
        return cv;
    }
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
