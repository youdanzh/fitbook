package com.fitbook.fitbook;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


public class RecordListActivity extends BaseActivity  {


    private RecyclerView recyclerview;
    private List<EmployeeRecord> list = new ArrayList<>();
    private RecordAdapter mAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incomelist);
        onSetTitle("Paycheck List");
    }

    @Override
    protected void onResume() {
        super.onResume();
        init();
    }

    private void init() {

        recyclerview =  findViewById(R.id.recyclerview);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
        recyclerview.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        list.clear();
        int id = (int) SPUtils.get(this, "id", 0);
        List<EmployeeRecord> datas = DBDao.getInstance(this).loadRecordByUser(id);
        list.addAll(datas);
        mAdapter = new RecordAdapter(this,list);
        recyclerview.setAdapter(mAdapter);

    }




}
