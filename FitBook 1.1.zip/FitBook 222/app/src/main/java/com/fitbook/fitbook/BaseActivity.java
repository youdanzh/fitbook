package com.fitbook.fitbook;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;



public class BaseActivity extends AppCompatActivity {

    //Set title
    public void onSetTitle(String title) {
        Toolbar toolbar =  findViewById(R.id.at_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.back_arr);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onReturn();
            }
        });
        TextView mTitle = toolbar.findViewById(R.id.at_title);
        mTitle.setText(title);
    }
    public void onToast(String msg) {

        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onDestroy() {

        super.onDestroy();
    }
    public void onReturn(){

        finish();
    }


}