package com.fitbook.fitbook;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ChangePhoneActivity extends BaseActivity implements View.OnClickListener {


    EditText etPhone;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changephone);
        onSetTitle("Change");
        etPhone = findViewById(R.id.et_phone);
        btnLogin = findViewById(R.id.btn_login);
        btnLogin.setOnClickListener(this);
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_login:
                int id = (int) SPUtils.get(this, "id", 0);
                User user = DBDao.getInstance(this).getUserInfoById(id);
                String phone = etPhone.getText().toString();
                if (TextUtils.isEmpty(phone)){
                    return;
                }
                user.setUtel(phone);

                DBDao.getInstance(this).updateUser(user);
                finish();
                break;
        }
    }
}
