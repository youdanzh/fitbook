package com.fitbook.fitbook;
import java.util.Calendar;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.Date;
import android.widget.TextView;

//Class for employee to clock in and clock out
public class Employee extends BaseActivity implements View.OnClickListener {


    private TextView tv_status;
    private int id;
    private Button clockOut;
    private Button clockIn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.employeeview);
        initView();
        onSetTitle("Employee Information");
        id = (int) SPUtils.get(this, "id", 0);
        UpdateWorkInfo();
    }
    public  void UpdateWorkInfo(){
        Work workInfo = DBDao.getInstance(this).getWorkInfo(id);
        if (workInfo!=null) {
            if (workInfo.getStatus()==0){
                //Employee clock in
                tv_status.setText("Working"+"---Clock in: "+workInfo.getTime());
            }else {
                tv_status.setText("Not Working Time");
            }
        }
    }
    private void initView() {
        tv_status = findViewById(R.id.tv_status);
        clockOut = findViewById(R.id.clockOut);
        clockIn = findViewById(R.id.clockIn);
        Button btCheck = findViewById(R.id.bt_check);
        clockOut.setOnClickListener(this);
        clockIn.setOnClickListener(this);
        btCheck.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Work workInfo = DBDao.getInstance(this).getWorkInfo(id);
        switch (view.getId()){
            case R.id.bt_check:
                startActivity(new Intent(Employee.this,RecordListActivity.class));
                break;
            case R.id.clockIn:

                if (workInfo!=null) {
                    if (workInfo.getStatus()==0){
                        onToast("Currently Working");
                        return;
                    }else {
                        workInfo.setStatus(0);
                        workInfo.setTime(Work.getNowTime());
                        DBDao.getInstance(this).updateWork(workInfo);
                    }
                }else{
                    workInfo = new Work(0,id,Work.getNowTime(),0);
                    DBDao.getInstance(this).addWork(workInfo);
                }
                UpdateWorkInfo();
                break;
            case R.id.clockOut:
                if (workInfo!=null) { //Employee has not clocked in so he/she cant clock out
                    if (workInfo.getStatus()==1){
                        onToast("Cannot clock out");
                        return;
                    }else {
                        workInfo.setStatus(1);
                        workInfo.setTime(Work.getNowTime());
                        int hours = Work.hour(workInfo.getTime(),Work.getNowTime());
                        if (hours<=0){ //Employee did not work more than 1 hour
                            onToast("Worked less than 1 hour");
                        }else{
                           //At least 1 hour worked, saved data
                            //(String startTime, String endTime, String salary, String total, int userId
                            workInfo.setHours(workInfo.getHours()+hours);
                            DBDao.getInstance(this).updateWork(workInfo);

                            String salary = DBDao.getInstance(this).getUserInfoById(id).getSalary();
                            int num = Integer.parseInt(salary)*hours;
                            EmployeeRecord record = new EmployeeRecord(workInfo.getTime(), Work.getNowTime(),salary, num+"",id);
                            DBDao.getInstance(this).addRecord(record);
                        }
                        DBDao.getInstance(this).updateWork(workInfo);
                    }
                }else{
                    onToast("Cannot clock out");
                }
                UpdateWorkInfo();
                break;
        }
    }
}




